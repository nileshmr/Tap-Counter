import { useState, useRef, useCallback } from "react";
import { Pencil, Check, RotateCcw } from "lucide-react";

interface Side {
  name: string;
  emoji: string;
  count: number;
  color: "red" | "blue";
}

const DEFAULT_SIDES: [Side, Side] = [
  { name: "Player A", emoji: "👑", count: 0, color: "red" },
  { name: "Player B", emoji: "😎", count: 0, color: "blue" },
];

function EditModal({
  side,
  onSave,
  onClose,
}: {
  side: Side;
  onSave: (name: string, emoji: string) => void;
  onClose: () => void;
}) {
  const [name, setName] = useState(side.name);
  const [emoji, setEmoji] = useState(side.emoji);

  const emojis = ["👑", "😎", "🔥", "⚡", "🎯", "💪", "🏆", "🎪", "🦁", "🐯", "🚀", "💎"];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl p-6 w-80 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-bold text-gray-800 mb-4 text-center">Edit Player</h3>
        <div className="mb-4">
          <label className="text-sm text-gray-500 mb-1 block">Name</label>
          <input
            className="w-full border-2 border-gray-200 rounded-xl px-4 py-2 text-gray-800 font-medium focus:outline-none focus:border-gray-400"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={12}
            autoFocus
          />
        </div>
        <div className="mb-6">
          <label className="text-sm text-gray-500 mb-2 block">Emoji</label>
          <div className="grid grid-cols-6 gap-2">
            {emojis.map((e) => (
              <button
                key={e}
                onClick={() => setEmoji(e)}
                className={`text-2xl p-1 rounded-xl transition-all ${
                  emoji === e ? "bg-gray-200 scale-110" : "hover:bg-gray-100"
                }`}
              >
                {e}
              </button>
            ))}
          </div>
        </div>
        <button
          onClick={() => onSave(name.trim() || side.name, emoji)}
          className="w-full bg-gray-800 text-white rounded-xl py-3 font-semibold flex items-center justify-center gap-2 hover:bg-gray-700 active:scale-95 transition-all"
        >
          <Check size={18} /> Save
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [sides, setSides] = useState<[Side, Side]>(DEFAULT_SIDES);
  const [editing, setEditing] = useState<0 | 1 | null>(null);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number; side: 0 | 1 }[]>([]);
  const rippleId = useRef(0);

  const handleTap = useCallback(
    (sideIdx: 0 | 1, e: React.MouseEvent<HTMLDivElement>) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const id = rippleId.current++;

      setRipples((prev) => [...prev, { id, x, y, side: sideIdx }]);
      setTimeout(() => setRipples((prev) => prev.filter((r) => r.id !== id)), 600);

      setSides((prev) => {
        const next: [Side, Side] = [{ ...prev[0] }, { ...prev[1] }];
        next[sideIdx] = { ...next[sideIdx], count: next[sideIdx].count + 1 };
        return next;
      });
    },
    []
  );

  const handleSave = (idx: 0 | 1, name: string, emoji: string) => {
    setSides((prev) => {
      const next: [Side, Side] = [{ ...prev[0] }, { ...prev[1] }];
      next[idx] = { ...next[idx], name, emoji };
      return next;
    });
    setEditing(null);
  };

  const handleReset = () => {
    setSides((prev) => [
      { ...prev[0], count: 0 },
      { ...prev[1], count: 0 },
    ]);
  };

  const total = sides[0].count + sides[1].count;
  const aPercent = total === 0 ? 50 : (sides[0].count / total) * 100;
  const bPercent = 100 - aPercent;

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col select-none" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Top score bar */}
      <div className="relative flex items-center justify-center z-20" style={{ height: 52 }}>
        <div className="absolute inset-0 flex">
          <div className="flex-1" style={{ background: "#e03535" }} />
          <div className="flex-1" style={{ background: "#1a6fd4" }} />
        </div>
        <div className="relative flex items-center gap-3 bg-gray-900 rounded-b-2xl px-5 py-2 shadow-xl">
          <span className="font-black text-xl tabular-nums" style={{ minWidth: 24, textAlign: "center", color: "#ff7272" }}>
            {sides[0].count}
          </span>
          <div className="w-px h-4 bg-gray-600" />
          <span className="font-black text-xl tabular-nums" style={{ minWidth: 24, textAlign: "center", color: "#6faeff" }}>
            {sides[1].count}
          </span>
        </div>
        <button
          onClick={handleReset}
          className="absolute right-3 top-1/2 -translate-y-1/2 bg-gray-900 text-white rounded-full p-1.5 hover:bg-gray-700 active:scale-90 transition-all z-30"
          style={{ lineHeight: 0 }}
          title="Reset"
        >
          <RotateCcw size={16} />
        </button>
      </div>

      {/* Main tap area */}
      <div className="flex flex-1 relative">
        {([0, 1] as const).map((idx) => {
          const side = sides[idx];
          const bg = idx === 0 ? "#e03535" : "#1a6fd4";
          const sideRipples = ripples.filter((r) => r.side === idx);

          return (
            <div
              key={idx}
              className="relative flex-1 flex flex-col items-center justify-center overflow-hidden cursor-pointer active:brightness-95"
              style={{ background: bg }}
              onClick={(e) => handleTap(idx, e)}
            >
              {/* Ripple effects */}
              {sideRipples.map((r) => (
                <span
                  key={r.id}
                  className="pointer-events-none absolute rounded-full"
                  style={{
                    left: r.x,
                    top: r.y,
                    width: 10,
                    height: 10,
                    marginLeft: -5,
                    marginTop: -5,
                    background: "rgba(255,255,255,0.35)",
                    animation: "ripple 0.6s ease-out forwards",
                  }}
                />
              ))}

              {/* Edit button */}
              <button
                className="absolute top-4 text-white/70 hover:text-white transition-colors active:scale-90 z-10"
                style={{ [idx === 0 ? "left" : "right"]: 16 }}
                onClick={(e) => {
                  e.stopPropagation();
                  setEditing(idx);
                }}
              >
                <Pencil size={20} />
              </button>

              {/* Content */}
              <div className="flex flex-col items-center gap-2 pointer-events-none">
                <span className="text-5xl mb-1" role="img">{side.emoji}</span>
                <span className="text-white font-bold text-xl tracking-wide drop-shadow">
                  {side.name}
                </span>
                <span
                  className="text-white font-black tabular-nums drop-shadow-lg"
                  style={{ fontSize: "clamp(72px, 18vw, 140px)", lineHeight: 1, letterSpacing: "-2px" }}
                >
                  {side.count}
                </span>
              </div>

              {/* Bottom percentage bar */}
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/10">
                <div
                  className="h-full bg-white/40 transition-all duration-300"
                  style={{ width: `${idx === 0 ? aPercent : bPercent}%` }}
                />
              </div>
            </div>
          );
        })}

        {/* Center divider */}
        <div
          className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1 z-10"
          style={{ background: "rgba(0,0,0,0.25)" }}
        />
      </div>

      {editing !== null && (
        <EditModal
          side={sides[editing]}
          onSave={(name, emoji) => handleSave(editing, name, emoji)}
          onClose={() => setEditing(null)}
        />
      )}

      <style>{`
        @keyframes ripple {
          from { transform: scale(1); opacity: 1; }
          to { transform: scale(30); opacity: 0; }
        }
      `}</style>
    </div>
  );
}
